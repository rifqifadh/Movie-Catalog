import XCTest

import MovieTests

var tests = [XCTestCaseEntry]()
tests += MovieTests.allTests()
XCTMain(tests)
