import XCTest

import NetworkingTests

var tests = [XCTestCaseEntry]()
tests += NetworkingTests.allTests()
XCTMain(tests)
